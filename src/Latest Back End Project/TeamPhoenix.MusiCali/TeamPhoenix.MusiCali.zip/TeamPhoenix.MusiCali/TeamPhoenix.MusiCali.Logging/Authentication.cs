﻿namespace TeamPhoenix.MusiCali.Logging
{
    public class Authentication
    {
        public static bool logFailure(string userHash)
        {
            return false;
        }
    }
}
