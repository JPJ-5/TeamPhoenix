﻿namespace TeamPhoenix.MusiCali.Models
{
    public class RecoverRequest
    {
        public string UserName { get; set; }
        public string GivenOTP { get; set; }

    }
}
