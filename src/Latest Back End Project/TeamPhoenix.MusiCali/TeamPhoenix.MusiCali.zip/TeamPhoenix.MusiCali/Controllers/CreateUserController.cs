﻿//using Microsoft.AspNetCore.Mvc;
//using uC = TeamPhoenix.MusiCali.Services.UserCreation;

//namespace TeamPhoenix.MusiCali.Controllers
//{
//    [ApiController]
//    [Route("api/[controller]")]
//    public class CreateUserController : ControllerBase
//    {
//        [HttpPost]
//        public bool createdUser(string email, DateTime dOB, string username, string fname, string lname, string q, string a)
//        {
//            if (uC.RegisterUser(email, dOB, username, fname, lname, q, a))
//            {
//                return true;
//            }
//            return false;

//        }
//    }
//}
