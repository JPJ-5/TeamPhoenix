﻿using TeamPhoenix.MusiCali.DataAccessLayer.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
//using TeamPhoenix.MusiCali.Security;
using TeamPhoenix.MusiCali.Security;
using TeamPhoenix.MusiCali.Security.Contracts;

namespace AccCreationAPI.Controllers
{
    [Authorize]
    [Route("[controller]")]
    [ApiController]

    public class LoginController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public LoginController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        //private readonly IAuthentication _authentication;


        //public LoginController(IAuthentication authentication)
        //{
        //    _authentication = authentication;
        //}

        [AllowAnonymous]
        [HttpPost]
        public async Task<IActionResult> Login([FromBody] LoginModel login)
        {
            //// Replace this with actual database check
            //var userIsValid = await CheckCredentials(login.Username, login.Otp);
            Authentication newAuth = new Authentication(_configuration);
            var userIsValid = newAuth.AuthenticateUsername(login.Username);
            if (userIsValid)
            {
                var token = newAuth.Authenticate(login.Username, login.Otp);
                if (token != null)
                {
                    return Ok();
                }
                    
            }

            return BadRequest("Login Failed");
        }

        //private async Task<bool> CheckCredentials(string username, string otp)
        //{
        //    // Implement your database check here
        //    // Return true if credentials are valid, false otherwise

        //    return false;
        //}

        [HttpGet]
        public IActionResult Test()
        {
            return Ok("Token Successfully Validated");

        }






    }
}