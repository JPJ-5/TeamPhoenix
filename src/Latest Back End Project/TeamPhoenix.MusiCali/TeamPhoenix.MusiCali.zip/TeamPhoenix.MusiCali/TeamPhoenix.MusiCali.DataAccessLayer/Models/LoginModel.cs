﻿namespace TeamPhoenix.MusiCali.DataAccessLayer.Models
{
    public class LoginModel
    {
        public string Username { get; set; } = "";
        public string Otp { get; set; } = "";
    }
}